﻿using Microsoft.EntityFrameworkCore;

namespace ShoppingNirvanaInterview.Domain
{
    public class ShoppingDBContext : DbContext
    {
       
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set;}
        public DbSet<ShoppingCart> ShoppingCarts { get; set;}
        public DbSet<OrderProcess> OrderProcesses { get; set;}

    }
}
