﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoppingNirvanaInterview.Domain
{
    [Table("Product")]
    public class Product
    {
    [Key]
    public Guid Id { get; set; }
    public string Name { get; set; }
    public long Price { get; set; }
    public int Ratings { get; set; }
    public DateTime DateTime { get; set; }
        
    }
}
