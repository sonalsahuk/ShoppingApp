﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoppingNirvanaInterview.Domain
{
    [Table("ShoppingCart")]
    public class ShoppingCart
    {
        [Key]
        public Guid Id { get; set; }
        [ForeignKey("Product")]
        public Guid ProductId { get; set; }
        [ForeignKey("User")]
        public Guid UserId { get; set; }
        public DateTime CreatedDate { get; set; }


    }
}
