﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ShoppingNirvanaInterview.Domain
{
    [Table("OrderProcess")]
    public class OrderProcess
    {
        public Guid Id { get; set; }
        public int OrderId { get; set; } 
        public double Amount { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public DateTime CreatedDate { get; set; }
       




    }
}
