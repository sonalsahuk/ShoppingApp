﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoppingNirvanaInterview.Domain;
using ShoppingNirvanaInterview.Models;
using ShoppingNirvanaInterview.Services;

namespace ShoppingNirvanaInterview.Controllers
{
   [ApiController]
    public class UserController: ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;
        public UserController(IUserService userService, IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        [HttpPost("User/AddUser")]
        public async Task<ActionResult> Post(UserClient client)
        {
            try
            {
                User user = _mapper.Map<UserClient, User>(client);
                await _userService.AddUser(user);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return Ok(client);

        }

        [HttpDelete("User/DeleteUser({Id})")]
        public ActionResult Delete(Guid id)
        {
            try
            {
                _userService.DeleteUser(id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return NoContent();

        }


    }
}
