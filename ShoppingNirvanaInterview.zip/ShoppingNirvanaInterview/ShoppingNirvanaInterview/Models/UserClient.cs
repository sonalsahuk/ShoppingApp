﻿namespace ShoppingNirvanaInterview.Models
{
    public class UserClient
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
