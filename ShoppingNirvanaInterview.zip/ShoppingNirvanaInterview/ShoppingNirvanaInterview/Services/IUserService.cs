﻿using ShoppingNirvanaInterview.Domain;

namespace ShoppingNirvanaInterview.Services
{
    public interface IUserService
    {
        Task AddUser(User user);
        Task DeleteUser(Guid userId);
    }
}
