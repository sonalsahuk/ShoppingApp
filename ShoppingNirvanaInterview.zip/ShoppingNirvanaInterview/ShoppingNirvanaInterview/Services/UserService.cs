﻿using ShoppingNirvanaInterview.Domain;
using ShoppingNirvanaInterview.Repository;

namespace ShoppingNirvanaInterview.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository _userRepository)
        {
            _userRepository = _userRepository;

        }

        public IQueryable<User> GetUsers
        public async Task AddUser(User user)
        {
            await _userRepository.AddUser(user);
        }

        public async Task DeleteUser(Guid id)
        {
            var user = _userRepository.GetById(id);
            if(user == null)
            {
                throw new Exception("User cannot be null");
            }
            await _userRepository.DeleteUser(user);
        }

    }
}
