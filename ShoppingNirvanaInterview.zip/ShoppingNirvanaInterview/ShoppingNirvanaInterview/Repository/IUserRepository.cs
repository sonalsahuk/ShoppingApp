﻿using ShoppingNirvanaInterview.Domain;

namespace ShoppingNirvanaInterview.Repository
{
    public interface IUserRepository
    {
        IQueryable<User> GetUsers();
       Task AddUser(User user);
        Task DeleteUser(User user);
        User GetById(Guid Id);


    }
}
