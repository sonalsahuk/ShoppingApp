﻿using ShoppingNirvanaInterview.Domain;

namespace ShoppingNirvanaInterview.Repository
{
    public class UserRepository:IUserRepository
    {
        public ShoppingDBContext _dbcontext;

        public UserRepository(ShoppingDBContext dBContext)
        {
            _dbcontext = dBContext;
        }

        public IQueryable<User> GetUsers()
        {
            return _dbcontext.Users;
        }

        public async Task AddUser(User user)
        {
            _dbcontext.Users.Add(user);
            await _dbcontext.SaveChangesAsync();
        }

        public async Task DeleteUser(User user)
        {
            _dbcontext.Users.Remove(user);
            await _dbcontext.SaveChangesAsync();
        }

        public User GetById(Guid Id)
        {
            return _dbcontext.Users.Where(x => x.Id == Id).FirstOrDefault();
        }

    }
}
